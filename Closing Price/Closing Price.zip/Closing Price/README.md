# My Interview Project

Welcome to my awesome project! 
This project will search for GOOGL in google finance and get the previous closing numbers.

## Features

- Feature 1: Navigate to google finance.
- Feature 2: Search GOOGL.
- Feature 3: Get the previous closing price and
- Feature 4: Print the previous close to the console 

## Getting Started

To get started with this project, follow these steps:

1. Clone the repository.
2. Install the required dependencies.
3. Run the project.

## Usage

Here's how you can execute this project:

```terminal
$ mvn test -DsuiteXmlFile=testng.xml

